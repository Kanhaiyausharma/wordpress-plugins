<?php
$data = '{"common-sidebar":{"social_media_icons-3":[]}}';