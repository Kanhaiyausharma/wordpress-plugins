<?php get_template_part("footer", $GLOBALS['rt_layout'] ); ?>

<?php wp_footer(); ?>
</body>
</html>