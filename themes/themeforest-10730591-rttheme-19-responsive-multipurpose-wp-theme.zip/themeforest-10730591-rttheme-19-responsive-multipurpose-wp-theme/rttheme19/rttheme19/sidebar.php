<?php
	//load the widgets
	do_action( "rt_load_widgets"); 		
?>