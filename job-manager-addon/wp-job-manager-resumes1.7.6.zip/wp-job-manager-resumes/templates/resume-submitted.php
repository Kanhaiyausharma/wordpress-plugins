<?php
switch ( $resume->post_status ) :
	case 'publish' :
		printf( '<p>' . __( 'Resume created successfully. To view your resume <a href="%s">click here</a>.', 'wp-job-manager-resumes' ) . '</p>', get_permalink( $resume->ID ) );
	break;
	case 'pending' :
		printf( '<p>' . __( 'Resume created successfully. Your resume will be visible once approved.', 'wp-job-manager-resumes' ) . '</p>', get_permalink( $resume->ID ) );
	break;
	default :
		do_action( 'resume_manager_resume_submitted_content_' . str_replace( '-', '_', sanitize_title( $resume->post_status ) ), $resume );
	break;
endswitch;