<tr>
	<td>
		<input type="text" name="resume_url_name[]" value="<?php echo esc_attr( $name ); ?>" />
	</td>
	<td>
		<input type="text" name="resume_url[]" value="<?php echo esc_attr( $url ); ?>" />
	</td>
</tr>