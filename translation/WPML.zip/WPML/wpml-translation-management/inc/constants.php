<?php
define('WPML_TM_FOLDER', basename(WPML_TM_PATH));

define('WPML_TM_URL', plugins_url('', dirname(__FILE__)));
